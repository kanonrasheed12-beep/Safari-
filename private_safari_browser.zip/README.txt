Private Safari Browser (PWA)

Files:
- index.html
- style.css
- app.js
- manifest.webmanifest

To use on iPhone:
1. Upload these files to any static web host (for example GitHub Pages, Netlify, or Cloudflare Pages).
2. Open the hosted page in Safari.
3. Tap Share.
4. Tap Add to Home Screen.

Important:
This is a Safari-powered web app. It cannot force Safari into Private Browsing or create a separate cookie jar from Safari. For stronger local privacy, open Safari's Private tab group manually.
